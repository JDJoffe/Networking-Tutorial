-------------------------------------------------------------------
Ripped by Centrixe (previously Tiramisu6) @ The Models Resource.
https://www.models-resource.com/submitter/Centrixe/
-------------------------------------------------------------------
Ripped with Random Talking Bush & Ploaj's Smash Ultimate MaxScript.
Content � Nintendo and/or respective third-party companies.
-------------------------------------------------------------------